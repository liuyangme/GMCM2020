function y=mymodel(beta,x)
   
   
    X_2=[x(:,1).^2,x(:,2).^2,x(:,3).^2,x(:,4).^2,x(:,5).^2,x(:,6).^2];
    y=X_2*beta(1:6)'+x*beta(7:12)'+repmat(beta(13),length(x),1);

end