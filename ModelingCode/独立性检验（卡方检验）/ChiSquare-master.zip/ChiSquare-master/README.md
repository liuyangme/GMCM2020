# ChiSquare
I didn't like MATLAB's built in tools for calculating a 2x2 chi square test, so I made my own
